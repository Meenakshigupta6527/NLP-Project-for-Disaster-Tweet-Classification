# Create your views here.
from django.shortcuts import render, redirect
#from .models import Tweet
from django.http import HttpResponse

def tweet_predict(request):
    if request.POST:
        tweet_content = request.POST.get("tweet")
        
        if tweet_content:  # Ensure the tweet is not empty
            
            Tweet.objects.create(content=tweet_content)
            
           
            return render(request, "tweet-predict.html", {'message': 'Tweet submitted successfully!'})

    
    return render(request, "tweet-predict.html")